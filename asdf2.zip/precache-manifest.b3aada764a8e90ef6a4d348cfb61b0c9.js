self.__precacheManifest = [
  {
    "revision": "105e88bb4cfe26915d6d50607c9385e4",
    "url": "/static/media/videos.105e88bb.png"
  },
  {
    "revision": "0162b7f22ddd0f4c3a09",
    "url": "/static/css/main.9df827a8.chunk.css"
  },
  {
    "revision": "a20e8dbc488be2249a38",
    "url": "/static/js/1.a20e8dbc.chunk.js"
  },
  {
    "revision": "229c360febb4351a89df",
    "url": "/static/js/runtime~main.229c360f.js"
  },
  {
    "revision": "52dd8767ccebe20969a8e88dd1cf32cf",
    "url": "/static/media/cast.52dd8767.jpg"
  },
  {
    "revision": "63e0c237210db785f55c2011bcd87dc2",
    "url": "/static/media/tech.63e0c237.jpg"
  },
  {
    "revision": "4a37cadf6f0dc927645d42c39bf27baa",
    "url": "/static/media/band.4a37cadf.jpg"
  },
  {
    "revision": "36bd0ddade508f8d13754f9a88c9cd5c",
    "url": "/static/media/costumes.36bd0dda.jpg"
  },
  {
    "revision": "8c968f75390535cd5f6424ca82d4cf3f",
    "url": "/static/media/promos.8c968f75.jpg"
  },
  {
    "revision": "c446ae2c3fb6ee05ec9c14641865b800",
    "url": "/static/media/scripts.c446ae2c.jpg"
  },
  {
    "revision": "84d936cde69912fcaab8f1476f4452ad",
    "url": "/static/media/socials.84d936cd.jpg"
  },
  {
    "revision": "fd05e87d4bee9106968e9763173ca815",
    "url": "/static/media/webmin.fd05e87d.jpg"
  },
  {
    "revision": "37e9f532a8c86964dd09314fbf34afa4",
    "url": "/static/media/wellbeing.37e9f532.jpg"
  },
  {
    "revision": "01b899aace21f1a71097bdfb46ff9592",
    "url": "/static/media/design.01b899aa.PNG"
  },
  {
    "revision": "0162b7f22ddd0f4c3a09",
    "url": "/static/js/main.0162b7f2.chunk.js"
  },
  {
    "revision": "dea91ec8f1691789febe47041ac77569",
    "url": "/static/media/foh.dea91ec8.jpg"
  },
  {
    "revision": "3df55255b38ef8904d4e12d67b2520ba",
    "url": "/static/media/doge.3df55255.jpg"
  },
  {
    "revision": "5b919d8d83fb771f01b6e856f31f10fb",
    "url": "/static/media/choreos.5b919d8d.jpg"
  },
  {
    "revision": "d6a5c5d0c5dcb7bc1ec8e0c31dbc1499",
    "url": "/static/media/vocals.d6a5c5d0.jpg"
  },
  {
    "revision": "a79b38d0d562d712b5676b901d3377e9",
    "url": "/static/media/vos.a79b38d0.jpg"
  },
  {
    "revision": "f3906077020049c0a4ba3f3e7fdbb016",
    "url": "/static/media/pubs.f3906077.PNG"
  },
  {
    "revision": "75b86a7912ce011e38455e4f4187c103",
    "url": "/static/media/logo-black-transparent.75b86a79.png"
  },
  {
    "revision": "3044516c2c0dc05e1372c81e6cdb5d0c",
    "url": "/static/media/wisetech.3044516c.PNG"
  },
  {
    "revision": "e0e16cf7f62ee1f47f3180f4fdc0dd9c",
    "url": "/static/media/Arc-Clubs-Logo-Black-Transparent.e0e16cf7.png"
  },
  {
    "revision": "48d74b46a34621d2b9bf1333f22b6e3b",
    "url": "/static/media/CoffeeOnCampus.48d74b46.jpg"
  },
  {
    "revision": "ae2a7493faee3d22ef92fdb30cdf8ff1",
    "url": "/static/media/ImagineCup.ae2a7493.png"
  },
  {
    "revision": "abad732e6cf1325e38deedc86d9afd65",
    "url": "/static/media/logo-white-transparent.abad732e.png"
  },
  {
    "revision": "512e2c26077a64f44f57fb0d36028c6e",
    "url": "/static/media/promo.512e2c26.mp4"
  },
  {
    "revision": "bf9528db7fd3a958ad798119a3418f8a",
    "url": "/index.html"
  }
];